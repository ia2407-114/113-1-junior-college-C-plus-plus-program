#include <stdio.h>
#include <string.h>

#define SIZE 5
#define NAME_LEN 20

typedef struct {
    char name[NAME_LEN];  
    int id;               
    int math;             
    int computer;         
    float average;        
} Student;

void input_students(Student students[], int size);
void print_students(const Student students[], int size);
void sort_students_by_average(Student students[], int size);
void swap_students(Student* a, Student* b);

int main(void) {
    Student students[SIZE];

    input_students(students, SIZE);

    printf("\n�Ƨǫe���W��:\n");
    print_students(students, SIZE);

    sort_students_by_average(students, SIZE);

    printf("\n�̾ڥ������Z�Ƨǫ᪺�W�� (�Ѥj��p):\n");
    print_students(students, SIZE);

    return 0;
}

void input_students(Student students[], int size) {
    for (int i = 0; i < size; i++) {
        printf("��J�� %d ��ǥͪ����:\n", i + 1);
        printf("�m�W: ");
        scanf_s("%s", students[i].name, NAME_LEN);
        printf("�Ǹ�: ");
        scanf_s("%d", &students[i].id);
        printf("�ƾǦ��Z: ");
        scanf_s("%d", &students[i].math);
        printf("�q�����Z: ");
        scanf_s("%d", &students[i].computer);

        students[i].average = (students[i].math + students[i].computer) / 2.0;
    }
}

void print_students(const Student students[], int size) {
    printf("�m�W\t�Ǹ�\t�ƾ�\t�q��\t����\n");
    for (int i = 0; i < size; i++) {
        printf("%s\t%d\t%d\t%d\t%.2f\n",
            students[i].name,
            students[i].id,
            students[i].math,
            students[i].computer,
            students[i].average);
    }
}

void sort_students_by_average(Student students[], int size) {
    for (int pass = 0; pass < size - 1; pass++) {
        for (int i = 0; i < size - 1 - pass; i++) {
            if (students[i].average < students[i + 1].average) {
                swap_students(&students[i], &students[i + 1]);
            }
        }
    }
}

void swap_students(Student* a, Student* b) {
    Student temp = *a;
    *a = *b;
    *b = temp;
}

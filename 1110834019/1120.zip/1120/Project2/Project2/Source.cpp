#include <stdio.h>


#define ROWS 5
#define COLS 4
float avg_score(int score[ROWS][COLS], int rows);

float avg_score(int score[ROWS][COLS], int rows) {
    float total_sum = 0;  
    int total_count = 0;  

  
    for (int i = 0; i < rows; i++) {
        float student_sum = 0;
        for (int j = 1; j < COLS - 1; j++) {
            student_sum += score[i][j];
        }
        
        score[i][COLS - 1] = student_sum / (COLS - 2);

        
        total_sum += student_sum;
        total_count += (COLS - 2);
    }

    
    return total_sum / total_count;
}

int main() {
    
    int score[ROWS][COLS] = { 0 };

    printf("�п�J�C��P�Ǫ��Ǹ��B�p�����Z�P�ƾǦ��Z:\n");
    for (int i = 0; i < ROWS; i++) {
        printf("�� %d ��P��:\n", i + 1);
        printf("�Ǹ�: ");
        scanf_s("%d", &score[i][0]); 
        printf("�p�����Z: ");
        scanf_s("%d", &score[i][1]); 
        printf("�ƾǦ��Z: ");
        scanf_s("%d", &score[i][2]); 
    }

  
    float total_avg = avg_score(score, ROWS);

   
    printf("\n�Ǹ�\t�p��\t�ƾ�\t����\n");
    for (int i = 0; i < ROWS; i++) {
        printf("%d\t%d\t%d\t%d\n", score[i][0], score[i][1], score[i][2], score[i][COLS - 1]);
    }

    
    printf("�`����: %.2f\n", total_avg);

    return 0;
}
